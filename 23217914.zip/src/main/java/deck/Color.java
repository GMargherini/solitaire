package deck;

public enum Color{
	RED,
	BLACK
}