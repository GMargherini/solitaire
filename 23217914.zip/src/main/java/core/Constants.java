package core;

public class Constants {
    public static final String RED_TEXT = "\033[31m";
    public static final String WHITE_TEXT = "\033[37m";
}
