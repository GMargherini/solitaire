package core;

public class InvalidMoveException extends Exception {
}
